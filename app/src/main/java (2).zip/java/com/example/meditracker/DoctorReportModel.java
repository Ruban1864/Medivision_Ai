package com.example.meditracker;

public class DoctorReportModel {

    private String summary;
    private String reportUrl;
    private String patientId;

    public DoctorReportModel(String summary, String reportUrl, String patientId) {
        this.summary = summary;
        this.reportUrl = reportUrl;
        this.patientId = patientId;
    }

    public String getSummary() {
        return summary;
    }

    public String getReportUrl() {
        return reportUrl;
    }

    public String getPatientId() {
        return patientId;
    }
}