package com.example.meditracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private EditText etFullName, etEmail, etPassword,
            etConfirmPassword, etAge, etPhoneNumber;

    private RadioGroup rgRole;
    private Spinner spinnerDoctor;

    private String selectedRole = "patient";
    private String selectedDoctorId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        etFullName = findViewById(R.id.et_full_name);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        etAge = findViewById(R.id.et_age);
        etPhoneNumber = findViewById(R.id.et_phone_number);

        rgRole = findViewById(R.id.rg_role);
        spinnerDoctor = findViewById(R.id.spinner_doctor);

        Button btnRegister = findViewById(R.id.btn_register);
        TextView tvLogin = findViewById(R.id.tv_login);

        setupPasswordToggle();
        setupRoleSelection();

        btnRegister.setOnClickListener(v -> registerUser());

        tvLogin.setOnClickListener(v ->
                startActivity(new Intent(this, LoginActivity.class)));
    }

    private void setupPasswordToggle() {

        etPassword.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (event.getRawX() >= (etPassword.getRight()
                        - etPassword.getCompoundDrawables()[2]
                        .getBounds().width())) {
                    togglePasswordVisibility(etPassword);
                    return true;
                }
            }
            return false;
        });

        etConfirmPassword.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (event.getRawX() >= (etConfirmPassword.getRight()
                        - etConfirmPassword.getCompoundDrawables()[2]
                        .getBounds().width())) {
                    togglePasswordVisibility(etConfirmPassword);
                    return true;
                }
            }
            return false;
        });
    }

    private void setupRoleSelection() {

        rgRole.setOnCheckedChangeListener((group, checkedId) -> {

            RadioButton selected =
                    findViewById(checkedId);

            selectedRole = selected.getText()
                    .toString().toLowerCase();

            if (selectedRole.equals("patient")) {
                spinnerDoctor.setVisibility(View.VISIBLE);
                loadDoctors();
            } else {
                spinnerDoctor.setVisibility(View.GONE);
                selectedDoctorId = null;
            }
        });
    }

    private void loadDoctors() {

        List<String> doctorNames = new ArrayList<>();
        List<String> doctorIds = new ArrayList<>();

        db.collection("users")
                .whereEqualTo("role", "doctor")
                .get()
                .addOnSuccessListener(query -> {

                    for (DocumentSnapshot doc : query) {
                        doctorNames.add(doc.getString("fullName"));
                        doctorIds.add(doc.getId());
                    }

                    ArrayAdapter<String> adapter =
                            new ArrayAdapter<>(this,
                                    android.R.layout.simple_spinner_item,
                                    doctorNames);

                    adapter.setDropDownViewResource(
                            android.R.layout.simple_spinner_dropdown_item);

                    spinnerDoctor.setAdapter(adapter);

                    spinnerDoctor.setOnItemSelectedListener(
                            new AdapterView.OnItemSelectedListener() {

                                @Override
                                public void onItemSelected(
                                        AdapterView<?> parent,
                                        View view,
                                        int position,
                                        long id) {

                                    selectedDoctorId =
                                            doctorIds.get(position);
                                }

                                @Override
                                public void onNothingSelected(
                                        AdapterView<?> parent) {}
                            });
                });
    }

    private void registerUser() {

        String fullName = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword =
                etConfirmPassword.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String phoneNumber =
                etPhoneNumber.getText().toString().trim();

        if (fullName.isEmpty() || email.isEmpty() ||
                password.isEmpty() || confirmPassword.isEmpty() ||
                ageStr.isEmpty() || phoneNumber.isEmpty()) {

            Toast.makeText(this,
                    "Please fill all fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this,
                    "Passwords do not match",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this,
                    "Password must be at least 6 characters",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        int age;
        try {
            age = Integer.parseInt(ageStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this,
                    "Age must be a number",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedRole.equals("patient")
                && selectedDoctorId == null) {

            Toast.makeText(this,
                    "Please select a doctor",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {

                    if (task.isSuccessful()) {

                        String userId =
                                auth.getCurrentUser().getUid();

                        Map<String, Object> userData =
                                new HashMap<>();

                        userData.put("fullName", fullName);
                        userData.put("email", email);
                        userData.put("age", age);
                        userData.put("phoneNumber", phoneNumber);
                        userData.put("role", selectedRole);

                        if (selectedRole.equals("patient")) {
                            userData.put("assignedDoctorId",
                                    selectedDoctorId);
                        }

                        db.collection("users")
                                .document(userId)
                                .set(userData)
                                .addOnSuccessListener(aVoid -> {

                                    Toast.makeText(this,
                                            "Registration successful",
                                            Toast.LENGTH_SHORT).show();

                                    startActivity(new Intent(
                                            this,
                                            MainActivity.class));

                                    finish();
                                });

                    } else {
                        Toast.makeText(this,
                                "Registration failed: "
                                        + task.getException().getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void togglePasswordVisibility(EditText editText) {

        boolean isVisible =
                editText.getTransformationMethod() == null;

        if (isVisible) {
            editText.setTransformationMethod(
                    new PasswordTransformationMethod());
        } else {
            editText.setTransformationMethod(null);
        }

        editText.setSelection(
                editText.getText().length());
    }
}