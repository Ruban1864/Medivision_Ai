package com.example.meditracker;

public class ReportModel {

    private String id;
    private String name;
    private String summary;
    private String url;

    public ReportModel(String id, String name, String summary, String url) {
        this.id = id;
        this.name = name;
        this.summary = summary;
        this.url = url;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getSummary() { return summary; }
    public String getUrl() { return url; }
}