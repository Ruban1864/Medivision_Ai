package com.example.meditracker;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_detail);

        TextView tvTitle = findViewById(R.id.tv_report_name);
        TextView tvSummary = findViewById(R.id.tv_summary);

        String name = getIntent().getStringExtra("name");
        String summary = getIntent().getStringExtra("summary");

        tvTitle.setText(name);
        tvSummary.setText(summary);
        tvSummary.setMovementMethod(ScrollingMovementMethod.getInstance());
    }
}