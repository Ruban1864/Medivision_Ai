package com.example.meditracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class DoctorDashboardActivity extends AppCompatActivity {

    private RecyclerView recyclerReports;
    private ProgressBar progressBar;
    private TextView txtEmpty;

    private FirebaseFirestore db;
    private String doctorId;

    private List<DoctorReportModel> reportList;
    private DoctorReportAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_dashboard);

        recyclerReports = findViewById(R.id.recyclerReports);
        progressBar = findViewById(R.id.progressBar);
        txtEmpty = findViewById(R.id.txtEmpty);

        recyclerReports.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        doctorId = FirebaseAuth.getInstance().getUid();

        reportList = new ArrayList<>();
        adapter = new DoctorReportAdapter(reportList, this);
        recyclerReports.setAdapter(adapter);

        loadAssignedReports();
    }

    private void loadAssignedReports() {

        progressBar.setVisibility(View.VISIBLE);

        db.collectionGroup("reports")   // 🔥 Correct way
                .whereEqualTo("doctorId", doctorId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {

                    progressBar.setVisibility(View.GONE);
                    reportList.clear();

                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {

                        String summary = doc.getString("summary");
                        String reportUrl = doc.getString("url");   // 🔥 corrected
                        String patientId = doc.getString("patientId");

                        if (summary != null) {
                            reportList.add(
                                    new DoctorReportModel(summary, reportUrl, patientId)
                            );
                        }
                    }

                    adapter.notifyDataSetChanged();

                    if (reportList.isEmpty()) {
                        txtEmpty.setVisibility(View.VISIBLE);
                    } else {
                        txtEmpty.setVisibility(View.GONE);
                    }
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this,
                            "Failed to load reports",
                            Toast.LENGTH_SHORT).show();
                });
    }
}