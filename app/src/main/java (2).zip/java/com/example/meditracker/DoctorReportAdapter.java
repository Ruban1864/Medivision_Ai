package com.example.meditracker;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DoctorReportAdapter
        extends RecyclerView.Adapter<DoctorReportAdapter.ViewHolder> {

    List<DoctorReportModel> list;
    Context context;

    public DoctorReportAdapter(List<DoctorReportModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_doctor_report, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        DoctorReportModel model = list.get(position);

        holder.txtSummary.setText(model.getSummary());

        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(context, HistoryDetailActivity.class);
            intent.putExtra("summary", model.getSummary());
            intent.putExtra("url", model.getReportUrl());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtSummary;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtSummary = itemView.findViewById(R.id.txtSummary);
        }
    }
}